#!/bin/bash

mongod -f /etc/mongod_slave.conf  #--auth #--replSet rs1
