#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
import config
from app import app




if __name__ == '__main__':

    app.run(host=config.host, port=config.port, debug=config.debug)

