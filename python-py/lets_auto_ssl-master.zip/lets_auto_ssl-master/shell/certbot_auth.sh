#!/bin/bash
CREATE_DOMAIN="_acme-challenge.$CERTBOT_DOMAIN"
AUTH_KEY='fu4FDDh0YvaGeT3u'

for ((;;))
do
    status=`curl -s -X POST "http://127.0.0.1:5000/domain/ssl/dns/" \
        -H "X-LetsAutoSSL-Key: ${AUTH_KEY}" \
        -H "Content-Type: application/json" \
        --data '{"domain":"'"$CREATE_DOMAIN"'","token":"'"$CERTBOT_VALIDATION"'"}'`

    if [[ $status == '"True"' ]];then
        break
    fi
    sleep 5
done
sleep 10

