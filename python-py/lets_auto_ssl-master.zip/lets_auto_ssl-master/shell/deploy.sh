#!/usr/bin/env bash
if [[ $(ps aux|grep "python"|grep "app.py"|grep -v "grep"|awk '{print $2}'|wc -l) -ge "1" ]];then
    ps aux|grep "python"|grep "app.py"|grep -v "grep"|awk '{print $2}'|xargs kill -9
    echo "发现进程存在 杀死进程中..."
    sleep 5
fi

cd /lets_auto_ssl/
nohup python3 app.py > /lets_auto_ssl/runlog 2>&1 &