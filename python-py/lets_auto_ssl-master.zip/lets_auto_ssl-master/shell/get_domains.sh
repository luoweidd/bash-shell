#!/usr/bin/env bash
function do_search() {
    nginx_path='/etc/nginx'
    a='None'
    if [[ `grep server_name ${nginx_path}/sites/${type}*|sort|uniq|wc -l` == '0' ]];then
        a="None"
    elif [[ `grep server_name ${nginx_path}/sites/${type}*|sort|uniq|wc -l` == '1' ]];then
        a=`grep server_name ${nginx_path}/sites/${type}*|sort|uniq|awk '{print $2}'|cut -d ';' -f1`
        a="\"$a\""
    else
        for domain in `grep server_name ${nginx_path}/sites/${type}*|sort|uniq|awk '{print $3}'|cut -d ';' -f1`
        do
            domain="\"$domain\""
            if [[ $a == 'None' ]]; then
                a="$domain"

            else
                a="$a, $domain"

            fi
        done
    fi
    if [[ $a != "None" ]];then
        echo "[$a]"
    else
        echo "$a"
    fi
}
case $1 in
    download )
        type="$1"
        do_search
        ;;
    pay )
        type="$1"
        do_search
        ;;
    ht )
        type="$1"
        do_search
        ;;
    kf )
        type="$1"
        do_search
        ;;
    kfapi )
        type="$1"
        do_search
        ;;
    agent )
        type="$1"
        do_search
        ;;
    www )
        type="$1"
        do_search
        ;;
    * )
        echo "error_type"
        exit 1
        ;;
esac