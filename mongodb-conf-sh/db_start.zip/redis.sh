#!/bin/bash

redis-server /etc/redis.conf
