#!/bin/bash

mongod -f /etc/mongod_config-2.conf  #--replSet rs1
