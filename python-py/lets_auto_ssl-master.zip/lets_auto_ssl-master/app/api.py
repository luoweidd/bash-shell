# -*- coding:UTF-8 -*-
from app import app
from flask import request
from flask import make_response
from concurrent.futures import ThreadPoolExecutor
import control
import config
import json
import time


system = control.System()
domain = control.Domain()
core = control.Core()

pool = ThreadPoolExecutor(max_workers=5)
loginKey = config.X_LetsAutoSSL_Key
# status code
message = dict()
message["success"] = False
msg = dict()
msg["01"] = "Hello, What can i do for you?"
msg["02"] = "is not exists. Please check."
msg["03"] = "got an incorrect value"
msg["04"] = "args is Wrong. Please check."


def return_msg(message):
    res = json.dumps(str(message))
    res = make_response(res)
    res.headers['Content-Type'] = 'application/json'
    res.headers['Server'] = 'Nginx/1.8.0'
    return res


def return_domain(domain_name):
    import tldextract
    domain_name = tldextract.extract(domain_name)
    domain_name = "{0}.{1}".format(domain_name.domain, domain_name.suffix)
    return domain_name


def apply_cert(domain_name, domain_type, server_ipaddr):
    core.debug("Start App_cert")
    redis_key = "Lock_{0}".format(domain_name)
    core.redis().set(redis_key, "True")
    domain_short_name = return_domain(domain_name)
    #  去CloudFlare的域名列表上查询
    res = domain.list(domain_short_name)
    core.debug("Get List Done")
    ns_status = False
    while True:
        # # 检测是否解析NS记录
        # core.debug("Start While")
        # core.debug(res)
        # for item in res:
        #     core.debug("start for item")
        #     core.debug(item)
        #     core.debug(domain.check_dns(domain_short_name, "NS"))
        #     if str(item) in str(domain.check_dns(domain_short_name, "NS")):
        #         ns_status = True
        #         time.sleep(10)
        #         break
        # if ns_status is True:
        #     break

        # 检测CloudFlare状态是否为True
        time.sleep(10)
        if "active" in str(domain.get_zone_status(domain_name)):
            ns_status = True
            break
        else:
            print("{0}. is not active from cloudflare. Auto recheck.".format(domain_name))

    if ns_status is True:
        core.debug("add reocrd {0} to {1}".format(domain_name, server_ipaddr))
        if domain.record_add("A", domain_name, server_ipaddr)["success"] is not True:
             message["msg"] = "Record add failed. Please contact administraotr"

        core.debug("app_certificate {0}".format(domain_name))
        if system.apply_certificate(domain_name) is None:
             message["msg"] = "apply certificate failed. Please contact administraotr"

        if "*" in str(domain_name):
            domain_name = domain_name.strip("*.")
        system.config_nginx(domain_name, domain_type)
    print("end")
    core.redis().delete(redis_key)


def hook_add_domain(record_type, domain_name, domain_value):
    redis_key = "Lock_record_{0}".format(domain_name)
    domain.record_add(record_type, domain_name, domain_value)
    core.redis().delete(redis_key)
    pass

# def return_ipaddr(domain_type):
#     try:
#         ipaddr = random.choice(config.Server_IPAddr[domain_type])
#     except KeyError:
#         ipaddr = None
#     if addr
#     return ipaddr


@app.route('/')
def hello_world():
    return 'Hello World!'


# 域名类型列表
@app.route('/system/get_type/', methods=["GET"])
def system_get_type():
    if request.headers.get("X-LetsAutoSSL-Key") is None or request.headers.get("X-LetsAutoSSL-Key") != loginKey:
        message["msg"] = msg["01"]
        return return_msg(message)

    message["success"] = True
    core.debug(list(config.Server_IPAddr.keys()))
    message["msg"] = list(config.Server_IPAddr.keys())
    return return_msg(message)


# 根据类型查询IP列表
@app.route("/system/ipaddr/", methods=["POST"])
def system_ipaddr():
    if request.headers.get("X-LetsAutoSSL-Key") is None or request.headers.get("X-LetsAutoSSL-Key") != loginKey:
        message["msg"] = msg["01"]
        return return_msg(message)

    try:
        response = json.loads(request.get_data().decode("utf8"))
    except json.decoder.JSONDecodeError:
        if request.get_data().decode("utf8") == '':
            message["msg"] = msg["01"]
            return return_msg(message)
    response = eval(response)

    if "type" not in str(response) or response["type"] is None or response["type"] == "":
        message["msg"] = "type {0}".format(msg["02"])
        return return_msg(message)


    message["success"] = True
    message["msg"] = config.Server_IPAddr[response["type"]]

    return return_msg(message)


# 服务器域名列表
@app.route('/domain/list/', methods=["GET"])
def domain_list():

    if request.headers.get("X-LetsAutoSSL-Key") is None or request.headers.get("X-LetsAutoSSL-Key") != loginKey:
        message["msg"] = msg["01"]
        return return_msg(message)

    if request.args.get("domain_type") is None:
        message["msg"] = "domain_type {0}".format(msg["02"])
        return return_msg(message)

    if ';' in request.args.get("domain_type"):
        message["msg"] = "domain_type {0}".format(msg["03"])
        return return_msg(message)
    domain_type = request.args.get("domain_type")
    message["msg"] = system.get_domains(domain_type).strip('\n')
    if message["msg"] == "error_type":
        return return_msg(message)
    message["msg"] = eval(message["msg"])

    if message["msg"] == "error_type":
        message["msg"] = "\"domain_type\" {0}".format(msg["03"])
        return return_msg(message)

    message["success"] = True

    if message["msg"] is None:
        message["msg"] = '"Name" : "None", "DNS_Status": None'
        return return_msg(message)

    return return_msg(message)


# 域名状态查询
@app.route("/domain/status/", methods=["POST"])
def domain_status():

    if request.headers.get("X-LetsAutoSSL-Key") is None or request.headers.get("X-LetsAutoSSL-Key") != loginKey:
        message["msg"] = msg["01"]
        return return_msg(message)

    try:
        response = json.loads(request.get_data().decode("utf8"))
    except json.decoder.JSONDecodeError:
        if request.get_data().decode("utf8") == '':
            message["msg"] = msg["01"]
            return return_msg(message)

    response = eval(response)

    if "domain" not in str(response) or response["domain"] is None or response["domain"] == "":
        message["msg"] = "domains {0}".format(msg["02"])
        return return_msg(message)
    if "type" not in str(response) or response["type"] is None or response["type"] == "":
        message["msg"] = "type {0}".format(msg["02"])
        return return_msg(message)
    message["success"] = True
    message["is_CloudFlare"] = False
    message["ns_check"] = False
    message["dns_check"] = False

    # 检测域名是否创建到CloudFlare
    domain_name = return_domain(response["domain"])
    res = domain.list(domain_name)
    if res is not None:
        message["is_CloudFlare"] = True

    # 检测是否解析NS记录
    for item in res:
        if str(item) in str(domain.check_dns(response["domain"], "NS")):
            message["ns_check"] = True
            break

    # 检测DNS是否到正确的IP地址
    if str(domain.check_dns(response["domain"], "A")[0]) in str(config.Server_IPAddr[response["type"]]):
        message["dns_check"] = True

    message["success"] = True

    return return_msg(message)


# 测试证书用的TXT记录
@app.route("/domain/ssl/dns/", methods=["POST"])
def domain_ssl_dns():

    if request.headers.get("X-LetsAutoSSL-Key") is None or request.headers.get("X-LetsAutoSSL-Key") != loginKey:
        print(return_msg(message))
        message["msg"] = msg["01"]
        return return_msg(message)

    try:
        response = json.loads(request.get_data().decode("utf8"))
    except json.decoder.JSONDecodeError:
        if request.get_data().decode("utf8") == '':
            message["msg"] = msg["01"]
            return return_msg(message)
    core.debug("domain/ssl/dns response: {0}".format(response))
    print(response)
    message["txt_check"] = False
    try:
        response = eval(response)
    except TypeError:
        pass

    if "domain" not in str(response) or response["domain"] is None or response["domain"] == "":
        message["msg"] = "domains {0}".format(msg["02"])
        return return_msg(message)

    if "token" not in str(response) or response["token"] is None or response["token"] == "":
        message["token"] = "token {0}".format(msg["02"])
        return return_msg(message)
    message["txt_check"] = False
    message["success"] = True
    # 检测注册证书用的txt记录

    if str(response["token"]) in str(domain.check_dns(response["domain"], "TXT")[0]):
        res = True
    else:
        redis_key = "Lock_record_{0}".format(response["domain"])
        if core.redis().get(redis_key) is None:
            pool.submit(hook_add_domain("TXT", response["domain"], response["token"]))

        res = False
    return return_msg(res)


# 增加域名绑定
@app.route("/domain/add/", methods=["POST"])
def domain_add():
    if request.headers.get("X-LetsAutoSSL-Key") is None or request.headers.get("X-LetsAutoSSL-Key") != loginKey:
        message["msg"] = msg["01"]
        return return_msg(message)

    try:
        response = json.loads(request.get_data().decode("utf8"))
    except json.decoder.JSONDecodeError:
        if request.get_data().decode("utf8") == '':
            message["msg"] = msg["01"]
            return return_msg(message)

    response = eval(response)

    if "domain" not in str(response) or response["domain"] is None or response["domain"] == "":
        message["msg"] = "domains {0}".format(msg["02"])
        return return_msg(message)
    if "type" not in str(response) or response["type"] is None or response["type"] == "":
        message["msg"] = "type {0}".format(msg["02"])
        return return_msg(message)
    if "ipaddr" not in str(response) or response["ipaddr"] is None or response["ipaddr"] == "":
        message["msg"] = "ipaddr {0}".format(msg["02"])
        return return_msg(message)

    redis_key = "Lock_{0}".format(response["domain"])
    if core.redis().get(redis_key) is None:
        core.redis().set(redis_key, "True")
        domain_name = return_domain(response["domain"])

        # 首先添加域名到CloudFlare
        name_server = domain.add(domain_name)
        server_ipaddr = response["ipaddr"]
        if str(server_ipaddr) not in str(config.Server_IPAddr[response["type"]]):
            message["msg"] = "ipaddr {0}".format(msg["04"])
            return return_msg(message)

        if "errors" not in str(name_server) or "Failed" not in str(name_server):
            print(name_server)
            if "already exists" in str(name_server):

                name_server = domain.list(domain_name)

            # 添加解析
            pool.submit(apply_cert, response["domain"], response["type"], server_ipaddr)

            message["success"] = True

        else:
            print("error")
            print(name_server)
        message["msg"] = name_server
    else:
        message["msg"] = "This domain is proceess on. Please waiting some time."
    return return_msg(message)





