#!/usr/bin/env bash
nginx_path="/etc/nginx/sites"

function add_nginx() {

    filename="${domain_type}_${domain_name}.conf"
    nginx_file="${nginx_path}/${filename}"

    # 复制模板文件到nginx
    cp ./shell/nginx_template.conf ${nginx_file}
    if [[ $? != '0' ]];then
        exit 1
    fi
    # 查找相关配置节点的行号
    echo ${nginx_file}
    ssl_cert_line=`grep -n "ssl_certificate " ${nginx_file}|awk -F':' '{print $1}'`
    echo $ssl_cert_line
    ssl_certkey_line=`grep -n "ssl_certificate_key" ${nginx_file}|awk -F':' '{print $1}'`
    echo $ssl_certkey_line
    serv_name_line=`grep -n "server_name" ${nginx_file}|awk -F':' '{print $1}'`
    echo $serv_name_line
    proxy_pass_line=`grep -n "proxy_pass" ${nginx_file}|awk -F':' '{print $1}'`
    echo $proxy_pass_line

    # 修改nginx配置文件

    sed -i "${ssl_cert_line}s/template.com/${domain_name}/g" ${nginx_file}
    sed -i "${ssl_certkey_line}s/template.com/${domain_name}/g" ${nginx_file}
    if [[ ${domain_type} == "download" ]];then
        sed -i "${serv_name_line}s/template.com/*.${domain_name}/g" ${nginx_file}
    else
        sed -i "${serv_name_line}s/template.com/${domain_name}/g" ${nginx_file}
    fi
    sed -i "${proxy_pass_line}s/template_pass/${domain_type}/g" ${nginx_file}


}

domain_name=${1}
domain_type=${2}
add_nginx
nginx -s reload