# -*- coding:UTF-8 -*-
class Core:

    def __init__(self):
        import config
        self.AccountID = config.AccountID
        self.header = config.CloudFlareHeader
        self.redis_host = config.redis_host
        self.redis_port = config.redis_port
        self.debug_config = config.debug

    def debug(self, data):
        if self.debug_config is True:
            print(data)

    def redis(self):
        import redis
        redis = redis.Redis(host=self.redis_host, port=self.redis_port)
        return redis

    def post(self, url, json):
        import requests
        try:
            requests_json = requests.post(url=url, data=json, headers=self.header)
            return requests_json.text
        except requests.exceptions.ConnectionError:
            requests_json = "[{'code': 1099, 'message': 'Can not connect CloudFlare API.'}]"
            return requests_json

    def get(self, url):
        import requests
        try:
            requests_json = requests.get(url=url, headers=self.header)
            return requests_json.text
        except requests.exceptions.ConnectionError:
            requests_json = "[{'code': 1099, 'message': 'Can not connect CloudFlare API.'}]"
            return requests_json

    def put(self, url, json):
        import requests
        try:
            requests_json = requests.put(url=url, data=json, headers=self.header)
            return requests_json.text
        except requests.exceptions.ConnectionError:
            requests_json = "[{'code': 1099, 'message': 'Can not connect CloudFlare API.'}]"
            return requests_json


    def delete(self, url):
        import requests
        try:
            requests_json = requests.delete(url=url, headers=self.header)
            return requests_json.text
        except requests.exceptions.ConnectionError:
            requests_json = "[{'code': 1099, 'message': 'Can not connect CloudFlare API.'}]"
            return requests_json


class Domain:
    def __init__(self):
        self.core = Core()

    def list(self, domain_name=None, list_type=False):
        import json
        self.core.debug("Start Get List")
        url = "https://api.cloudflare.com/client/v4/zones?account.id={0}".format(self.core.AccountID)
        response = self.core.get(url)
        response = json.loads(response)
        #self.core.debug(response)
        if list_type is False:
            if str(domain_name) not in str(response):
                self.core.debug("List: domain_name not in response")
                self.core.debug("domain: {0}".format(domain_name))
                self.core.debug("response: {0}".format(response))
                return None
            for item in response["result"]:
                self.core.debug("List: for item in response")
                if domain_name in str(item):
                    response = item["name_servers"]
                    break

        return response

    def get_zone_id(self, domain_name):
        from app import api
        domain_name = api.return_domain(domain_name)
        zone_id = None
        domain_list = self.list(list_type=True)
        for item in domain_list["result"]:
            if domain_name in str(item):
                zone_id = item["id"]
        return zone_id

    def get_zone_status(self, domain_name):
        from app import api
        domain_name = api.return_domain(domain_name)
        zone_status = None
        domain_list = self.list(list_type=True)
        for item in domain_list["result"]:
            if domain_name in str(item):
                zone_status = item["status"]
        return zone_status

    def add(self, domain_name):
        self.core.debug("Now Start Add Domain")
        import json
        data = dict()
        data["id"] = self.core.AccountID
        # data["id"] = '8154f94b191ff55728e8b741aef1eae4'
        post_json = dict()
        post_json['account'] = data
        post_json["name"] = domain_name
        post_json["jump_start"] = False
        post_json = json.dumps(post_json)
        url = 'https://api.cloudflare.com/client/v4/zones'
        response = self.core.post(url, post_json)
        self.core.debug(response)
        try:
            response = json.loads(response)["result"]["name_servers"]
        except TypeError:
            response = json.loads(response)["errors"]
        if "Failed to lookup registrar" in str(response):
            response = "Domain registrar failed. please "
            self.core.debug(response)
        self.core.debug("Add Domain End")
        return response

    def delete(self, domain_name):

        import json
        zone_id = self.get_zone_id(domain_name)
        # zone_id = '1'
        if zone_id is not None:
            url = 'https://api.cloudflare.com/client/v4/zones/{0}'.format(zone_id)
            response = self.core.delete(url)
            response = json.loads(response)
            # response = {"result":{"id":"cc5713afb23f9f80898bc70921ecc980"},"success":True,"errors":[],"messages":[]}
        else:
            response = "{0} not exists".format(domain_name)
        return response

    def get_record_id(self, sub_domain_name):
        url = 'https://api.cloudflare.com/client/v4/zones/{0}/dns_records?name={1}'.\
            format(self.get_zone_id(sub_domain_name), sub_domain_name)
        response = self.core.get(url)
        import json
        response = json.loads(response)
        print(response)
        try:
            return response["result"][0]["id"]
        except IndexError:
            if str(response["result"]) == '[]':
                return None

    def record_add(self, record_type, sub_domain_name, record_addr):
        import json
        data = dict()
        data["type"] = record_type
        data["name"] = sub_domain_name
        data["content"] = record_addr
        data["ttl"] = 1
        data["proxied"] = False
        data = json.dumps(data)

        if self.get_record_id(sub_domain_name) is None:
            url = 'https://api.cloudflare.com/client/v4/zones/{0}/dns_records'.format(self.get_zone_id(sub_domain_name))
            response = json.loads(self.core.post(url, data))
        else:
            url = 'https://api.cloudflare.com/client/v4/zones/{0}/dns_records/{1}' \
                .format(self.get_zone_id(sub_domain_name), self.get_record_id(sub_domain_name))
            response = json.loads(self.core.put(url, data))
        self.core.debug(response)
        return response

    def check_dns(self, sub_domain_name, dns_type):
        import dns.resolver
        import tldextract
        # print(sub_domain_name)
        # print(dns_type)
        if dns_type == 'NS':

            sub_domain_name = tldextract.extract(sub_domain_name)
            sub_domain_name = "{0}.{1}".format(sub_domain_name.domain, sub_domain_name.suffix)

        if dns_type == 'A' and '*' in sub_domain_name:
            sub_domain_name = tldextract.extract(sub_domain_name)
            sub_domain_name = "test.{0}.{1}".format(sub_domain_name.domain, sub_domain_name.suffix)

        try:
            msg = dns.resolver.query(sub_domain_name, dns_type)
        except dns.resolver.NoAnswer:
            return '[0.0.0.0]'
        except dns.resolver.NXDOMAIN:
            return '[0.0.0.0]'



        record = list()
        for record_list in msg.response.answer:
            for item in record_list:
                record.append(str(item))
        # print(record)
        # print(type(record))
        return record


class System:
    def __init__(self):
        self.core = Core()

    def get_domains(self, domain_type):
        import os
        process = os.popen("./shell/get_domains.sh {0}".format(domain_type))
        output = process.read()
        process.close()
        return output

    def apply_certificate(self, sub_domain_name):
        import os
        self.core.debug("System.App.Cert: Domain is: {0}".format(sub_domain_name))
        process = os.system("certbot certonly --manual --preferred-challenges=dns"
                            " --manual-auth-hook ./shell/certbot_auth.sh "
                            "--manual-public-ip-logging-ok  -d {0}".format(sub_domain_name))
        print("process status is {0}".format(process))
        if int(process) != 0:
            process = os.system("/root/certbot/certbot-auto certonly --manual --preferred-challenges=dns"
                            " --manual-auth-hook ./shell/certbot_auth.sh "
                            "--manual-public-ip-logging-ok  -d {0}".format(sub_domain_name))
        # process.close()
        # print(process)
        return process

    def config_nginx(self, sub_domain_name, domain_type):
        import os
        process = os.system("./shell/add_domains.sh {0} {1}".format(sub_domain_name, domain_type))
        return process



