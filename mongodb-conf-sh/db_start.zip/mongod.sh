#!/bin/bash

mongod -f /etc/mongod.conf    #--replSet rs1
