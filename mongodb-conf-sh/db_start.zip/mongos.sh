#!/bin/bash

mongos -f /etc/mongos.conf
