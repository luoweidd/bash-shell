#!/bin/bash

mongod -f /etc/mongod_config-1.conf    #--replSet rs1
