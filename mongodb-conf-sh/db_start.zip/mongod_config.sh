#!/bin/bash

mongod -f /etc/mongod_config.conf    #--replSet rs1
