#!/bin/bash

mongod -f /etc/mongod_slave-1.conf   --fork   --replSet rs1
